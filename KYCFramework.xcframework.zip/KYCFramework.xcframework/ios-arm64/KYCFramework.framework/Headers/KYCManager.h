//
//  KYCManager.h
//  KYCFramework
//
//  Created by Özgür Yalım on 7.04.2025.
//

#ifndef KYCManager_h
#define KYCManager_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class KYCManagerConfig;
@class Step;

NS_ASSUME_NONNULL_BEGIN

@interface KYCManager : NSObject

+ (instancetype)shared;

- (void)setPinnedCertificateFromURL:(nullable NSURL *)url
                    orEmbeddedFile:(nullable NSString *)fileName
                             isPEM:(BOOL)isPEM;

- (void)enterKYCFrom:(UINavigationController *)navigationController
         clientToken:(NSString *)clientToken
       applicationId:(NSString *)applicationId
           stepList:(NSArray<Step *> *)stepList
       configuration:(nullable KYCManagerConfig *)configuration
      initializeUrl:(NSString *)initializeUrl
        useLocation:(BOOL)useLocation;

@end

NS_ASSUME_NONNULL_END

#endif /* KYCManager_h */
