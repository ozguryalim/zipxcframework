//
//  KYCConfig.h
//  KYCFramework
//
//  Created by Özgür Yalım on 5.04.2025.
//

#ifndef KYCConfig_h
#define KYCConfig_h
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
 
@class UIConfig;
@class LivenessConfig;
 
NS_ASSUME_NONNULL_BEGIN
 
@interface KYCManagerConfig : NSObject
 
@property (nonatomic, strong, nullable) UIConfig *uiConfig;
@property (nonatomic) BOOL showCompletedScreen;
@property (nonatomic, strong, nullable) NSDictionary *cameraErrorMessage;
@property (nonatomic, strong, nullable) NSDictionary *nfcErrorMessage;
@property (nonatomic, strong, nullable) NSDictionary *videoCallErrorMessage;
@property (nonatomic, strong, nullable) NSDictionary *timeOutErrorMessage;
@property (nonatomic, strong, nullable) NSDictionary *serverErrorMessage;
@property (nonatomic, strong, nullable) NSDictionary *rejectedErrorMessage;
@property (nonatomic, strong, nullable) NSDictionary *identityReadFailedError;
@property (nonatomic, copy, nullable) NSString *videoCallSplashScreenAssetName;
@property (nonatomic, copy, nullable) NSString *closeIconAssetName;
@property (nonatomic, strong, nullable) LivenessConfig *livenessConfig;
 
- (instancetype)initWithUIConfig:(nullable UIConfig *)uiConfig
            showCompletedScreen:(BOOL)showCompletedScreen
            cameraErrorMessage:(nullable NSDictionary *)cameraErrorMessage
              nfcErrorMessage:(nullable NSDictionary *)nfcErrorMessage
        videoCallErrorMessage:(nullable NSDictionary *)videoCallErrorMessage
         timeOutErrorMessage:(nullable NSDictionary *)timeOutErrorMessage
         serverErrorMessage:(nullable NSDictionary *)serverErrorMessage
      rejectedErrorMessage:(nullable NSDictionary *)rejectedErrorMessage
   identityReadFailedError:(nullable NSDictionary *)identityReadFailedError
videoCallSplashScreenAssetName:(nullable NSString *)videoCallSplashScreenAssetName
      closeIconAssetName:(nullable NSString *)closeIconAssetName
          livenessConfig:(nullable LivenessConfig *)livenessConfig;
 
@end
 
@interface KYCManagerConfigBuilder : NSObject
 
- (instancetype)init;
 
- (KYCManagerConfigBuilder *)setUIConfig:(UIConfig *)uiConfig;
- (KYCManagerConfigBuilder *)setShowCompletedScreen:(BOOL)value;
- (KYCManagerConfigBuilder *)setCameraErrorMessage:(NSDictionary *)messages;
- (KYCManagerConfigBuilder *)setNFCErrorMessage:(NSDictionary *)messages;
- (KYCManagerConfigBuilder *)setVideoCallErrorMessage:(NSDictionary *)messages;
- (KYCManagerConfigBuilder *)setTimeOutErrorMessage:(NSDictionary *)messages;
- (KYCManagerConfigBuilder *)setServerErrorMessage:(NSDictionary *)messages;
- (KYCManagerConfigBuilder *)setRejectedErrorMessage:(NSDictionary *)messages;
- (KYCManagerConfigBuilder *)setIdentityReadFailedError:(NSDictionary *)messages;
- (KYCManagerConfigBuilder *)setVideoCallSplashScreenAssetName:(NSString *)name;
- (KYCManagerConfigBuilder *)setCloseIconAssetName:(NSString *)name;
- (KYCManagerConfigBuilder *)setLivenessConfig:(LivenessConfig *)config;
 
- (KYCManagerConfig *)build;
 
@end
 
NS_ASSUME_NONNULL_END


#endif /* KYCConfig_h */
