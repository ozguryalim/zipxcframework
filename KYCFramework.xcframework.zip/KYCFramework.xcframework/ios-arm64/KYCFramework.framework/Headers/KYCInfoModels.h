//
//  KYCInfoModels.h
//  KYCFramework
//
//  Created by Özgür Yalım on 5.04.2025.
//

#ifndef KYCInfoModels_h
#define KYCInfoModels_h

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface InfoPresentationModel : NSObject

@property (nonatomic, readonly) NSString *titleText;
@property (nonatomic, readonly) NSString *buttonText;
@property (nonatomic, readonly) NSString *descriptionText;
@property (nonatomic, readonly, nullable) NSString *assetName;
@property (nonatomic, readonly, nullable) NSString *lottieFileName;
@property (nonatomic, readonly) NSArray<NSString *> *bullets;
@property (nonatomic) BOOL cancelButtonIsActive;

- (instancetype)initWithTitleText:(NSString *)titleText
                       buttonText:(NSString *)buttonText
                  descriptionText:(NSString *)descriptionText
                        assetName:(nullable NSString *)assetName
                   lottieFileName:(nullable NSString *)lottieFileName
                          bullets:(NSArray<NSString *> *)bullets
            cancelButtonIsActive:(BOOL)cancelButtonIsActive;

@end

@interface InfoPresentationModelBuilder : NSObject

- (instancetype)init;

- (InfoPresentationModelBuilder *)setTitleText:(NSString *)titleText;
- (InfoPresentationModelBuilder *)setButtonText:(NSString *)buttonText;
- (InfoPresentationModelBuilder *)setDescriptionText:(NSString *)descriptionText;
- (InfoPresentationModelBuilder *)setAssetImageName:(NSString *)assetName;
- (InfoPresentationModelBuilder *)setBullets:(NSArray<NSString *> *)bullets;
- (InfoPresentationModelBuilder *)setCancelButtonIsActive:(BOOL)cancelButtonIsActive;
- (InfoPresentationModelBuilder *)setLottieFileName:(nullable NSString *)lottieFileName;

- (InfoPresentationModel *)build;

@end

NS_ASSUME_NONNULL_END

#endif /* KYCInfoModels_h */
