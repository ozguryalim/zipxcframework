//
//  KYCStep.h
//  KYCFramework
//
//  Created by Özgür Yalım on 7.04.2025.
//


#ifndef KYCStep_h
#define KYCStep_h

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, KYCStep) {
    KYCStepIdcardFront,
    KYCStepIdcardBack,
    KYCStepHologram,
    KYCStepNfc,
    KYCStepFace,
    KYCStepVideoCall
};

#endif /* KYCStep_h */
