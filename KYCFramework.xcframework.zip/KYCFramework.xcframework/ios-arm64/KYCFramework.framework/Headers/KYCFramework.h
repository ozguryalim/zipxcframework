//
//  KYCFramework.h
//  KYCFramework
//
//  Created by Mete Karakul on 26.06.2024.
//

#import <Foundation/Foundation.h>
//
#import <KYCFramework/KYCInfoModels.h>
#import <KYCFramework/KYCConfig.h>
#import <KYCFramework/StepModel.h>
#import <KYCFramework/KYCManager.h>
#import <KYCFramework/KYCStep.h>
//! Project version number for KYCFramework.
FOUNDATION_EXPORT double KYCFrameworkVersionNumber;

//! Project version string for KYCFramework.
FOUNDATION_EXPORT const unsigned char KYCFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KYCFramework/PublicHeader.h>


