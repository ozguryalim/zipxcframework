//
//  StepModel.h
//  KYCFramework
//
//  Created by Özgür Yalım on 5.04.2025.
//

#ifndef StepModel_h
#define StepModel_h

#import <Foundation/Foundation.h>

@class InfoPresentationModel;

NS_ASSUME_NONNULL_BEGIN

@interface Step : NSObject

@property (nonatomic, strong, nullable) InfoPresentationModel *infoView;
@property (nonatomic, copy, nullable) NSString *title;
@property (nonatomic, strong, nullable) NSNumber *identifyTimeout;
@property (nonatomic, strong, nullable) NSNumber *maxRetryCount;

- (instancetype)initWithInfoView:(nullable InfoPresentationModel *)infoView
                           title:(nullable NSString *)title
                identifyTimeout:(nullable NSNumber *)identifyTimeout
                 maxRetryCount:(nullable NSNumber *)maxRetryCount;

@end

@interface StepBuilder : NSObject

- (instancetype)init;

- (StepBuilder *)setInfoView:(nullable InfoPresentationModel *)infoView;
- (StepBuilder *)setTitle:(nullable NSString *)title;
- (StepBuilder *)setIdentifyTimeout:(nullable NSNumber *)identifyTimeout;
- (StepBuilder *)setStepType:(nullable NSNumber *)step;
- (Step *)build;

@end

NS_ASSUME_NONNULL_END

#endif /* StepModel_h */
